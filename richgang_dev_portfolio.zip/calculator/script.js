let currentInput = '';

function appendNumber(num) {
  currentInput += num;
  document.getElementById('result').value = currentInput;
}

function appendOperator(op) {
  currentInput += op;
  document.getElementById('result').value = currentInput;
}

function clearResult() {
  currentInput = '';
  document.getElementById('result').value = '';
}

function calculateResult() {
  try {
    currentInput = eval(currentInput);
    document.getElementById('result').value = currentInput;
  } catch (e) {
    document.getElementById('result').value = 'Error';
  }
}